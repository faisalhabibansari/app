npm install --save express@4.10.2

npm install --save socket.io

// socket.io chat

http://socket.io/get-started/chat/

// javascript - How to send a message to a particular client with socket.io - Stack Overflow

http://stackoverflow.com/questions/17476294/how-to-send-a-message-to-a-particular-client-with-socket-io

// on apigee npm install

http://apigee.com/docs/management/apis/post/organizations/%7Borg_name%7D/apis/%7Bapi_name%7D/revisions/%7Brevision_num%7D/npm

and

https://community.apigee.com/questions/4096/unable-to-install-apiproxy-with-npm-modules.html

// building apk

https://build.phonegap.com/

https://build.phonegap.com/apps/1483043/builds

faisal.iaito@gmail.com
faisal321252

// connection
http://stackoverflow.com/questions/9729308/socket-io-connection-url