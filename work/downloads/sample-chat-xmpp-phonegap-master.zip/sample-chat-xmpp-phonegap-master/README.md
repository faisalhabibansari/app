sample-chat-xmpp-phonegap
=========================

Simple XMPP chat with QuickBlox Web SDK, Strophe.js and modified for Phonegap
