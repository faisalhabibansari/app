//QB Account params
var QBPARAMS = {
	app_id      : 3907,
	auth_key    : 'jRVze-6OzVDh-WX',
	auth_secret : 'uX8dZDexGW8TrEe'
}

//Chat params
var CHAT = {
	server      : 'chat.quickblox.com',
	bosh_url    : 'http://chat.quickblox.com:5280',
	roomJID     : '3907_test@muc.chat.quickblox.com'
}
